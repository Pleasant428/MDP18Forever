from bluetooth import *
import time
import socket
from thread import *

bluetoothSocket=""
finish=0
start_bluetooth_server=0
start_inet_server=0
def connectBluetoothServer():
    global start_bluetooth_server
    start_bluetooth_server=0
    ss=BluetoothSocket(RFCOMM)
    ss.bind(("",PORT_ANY))
    ss.listen(1)
    port = ss.getsockname()[1]
    uuid = "94f39d29-7d6d-437d-973b-fba39e49d4ee"
    advertise_service( ss, "SampleServer",
                       service_id = uuid,
                       service_classes = [ uuid, SERIAL_PORT_CLASS ],
                       profiles = [ SERIAL_PORT_PROFILE ],
                       #                   protocols = [ OBEX_UUID ]
                       )

    print("Waiting for connection on RFCOMM channel %d" % port)
    global bluetoothSocket
    bluetoothSocket, client_info = ss.accept()
    print("Accepted connection from ", client_info)
    try:
        while True:
            data = bluetoothSocket.recv(1024)
            if len(data) == 0: break
            str = data.decode('utf-8')
            print("From bluetooth client ",str)
	    str=str+'\n'
            inetSocket.send(str.encode())
    except IOError:
        print("exception at bluetooth function")
        bluetoothSocket.close()
        ss.close()
        start_bluetooth_server=1
        #global finish
        #finish=1
        pass

    print("disconnected")
    bluetoothSocket.close()
    ss.close()
    start_bluetooth_server=1

def connectInetServer():
    global start_inet_server
    start_inet_server=0
    global inetSocket
    inetSocket= socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print("attempting to connect to android inet server")
    try:
        inetSocket.connect(("192.168.20.1",9999))
        print("connecting to android inet server ",inetSocket)
        while True:
            data = inetSocket.recv(1024)
            if len(data) == 0: 
		inetSocket.close()
	        start_inet_server=1
	        global finish
	        finish=1
		break
            str = data.decode('utf-8')
            print("From android inet server ",str)
            bluetoothSocket.send(str)
    except:
        print("exception at android inet function")
	inetSocket.close()
        start_inet_server=1
        global finish
        finish=1
        pass


start_new_thread(connectInetServer,())
start_new_thread(connectBluetoothServer,())
print("started bluetooth thread")
print("started inet thread")
while finish==0:
    #if start_inet_server==1:
        #start_new_thread(connectInetServer,())
    if start_bluetooth_server==1:
        start_new_thread(connectBluetoothServer,())
    time.sleep(1)

print("finishing program")

