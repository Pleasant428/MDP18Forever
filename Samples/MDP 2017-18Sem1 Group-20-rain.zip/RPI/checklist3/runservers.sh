#! bin/sh
sudo java -cp . RpiMain>LogRpiMain.log&
rpipid=$!
echo $rpipid
sleep 5
sudo python AndroidBridge.py>LogAndroid.log&
rpipid=$!
echo $rpipid
sudo python ArduinoBridge.py>LogArduino.log&
rpipid=$!
echo $rpipid
