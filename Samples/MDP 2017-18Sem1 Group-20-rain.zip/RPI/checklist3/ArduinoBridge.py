from bluetooth import *
import time
import socket
from thread import *
import serial
import logging

finish=0
start_inet_server=0
start_arduino_thread=0
def connectToArduino():
    #arduino connection code
    global start_arduino_thread
    start_arduino_thread=0
    try:
	global arduino
	portStr='/dev/ttyACM0'
	print("attempting to connect to arduino port 0")
	arduino = serial.Serial(portStr, 115200, timeout=.1)
	print("connected established with arduino")
    except:
    	global arduino
	portStr='/dev/ttyACM1'
	print("attempting to connect to arduino port 1")
	arduino = serial.Serial(portStr, 115200, timeout=.1)
	print("connected established with arduino")
    try:
        while True:
            data = arduino.readline() #the last bit gets rid of the new-line chars
            if data:
                print("received data: ",data.encode())
		data=data+'\n'
                inetSocket.send(data.encode())
    except:
        logging.exception("error at arduino connection")
        start_arduino_thread=1
        pass
    start_arduino_thread=1

def connectInetServer():
    global start_inet_server
    start_inet_server=0
    global inetSocket
    inetSocket= socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print("attempting to connect to arduino inet server")
    try:
        inetSocket.connect(("192.168.20.1",10000))
        print("connected to arduino inet server ",inetSocket)
        while True:
            data = inetSocket.recv(1024)
            if len(data) == 0: 
		inetSocket.close()
		arduino.close()
        	start_inet_server=1
        	global finish
	        finish=1
		break
            str = data.decode('utf-8')
            print("From arduino inet server ",str)
            arduino.write(str.encode('utf-8'))
	    #arduino.flush()
            print("sending to arduino: ",str.encode('utf-8'))
    except:
        print("exception at arduino inet function")
        start_inet_server=1
        global finish
        finish=1
	inetSocket.close()
	arduino.close()
        pass


start_new_thread(connectInetServer,())
start_new_thread(connectToArduino,())
print("started arduinocomm thread")
print("started inet thread")
while finish==0:
    #if start_inet_server==1:
    #start_new_thread(connectInetServer,())
    if start_arduino_thread==1:
        start_new_thread(connectToArduino,())
    time.sleep(1)
print("finishing program")

