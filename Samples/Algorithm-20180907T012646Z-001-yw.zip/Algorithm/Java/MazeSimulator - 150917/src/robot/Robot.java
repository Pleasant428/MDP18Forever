/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Queue;
import java.util.Stack;

import javax.swing.Timer;

import map.Grid;
import map.Constants;
import map.MapUI;
import robot.RobotConstant.DIRECTION;


public class Robot {

    int currentPosX, currentPosY;
    DIRECTION direction = null;
    
    // Robot's robot map
    private transient RobotMap _robotMap = null; // For determining next action
    private transient MapUI _mapUI = null; // For detecting obstacles
    private Grid[][] _grids = _robotMap.getMapGrids();
    
    public Robot(int currentPosX, int currentPosY, DIRECTION direction){
        this.currentPosX = currentPosX;
        this.currentPosY = currentPosY;
        this.direction = direction;
    }
    public void PossibleMove(){
        int oldPosX, oldPosY, newPosX, newPosY;
        
        oldPosX = currentPosX;
        oldPosY = currentPosY;
        
        if(!isLeftWall() && !isFrontWall() && !isRightWall()){
            rotateLeft();
            moveForward();
        }
        else if (!isLeftWall() && !isFrontWall() && isRightWall()){
            rotateLeft();
            moveForward();
        }
        else if(isLeftWall() && !isFrontWall() && !isRightWall()){
            moveForward();
        }
        else if(!isLeftWall() && isFrontWall() && !isRightWall()){
            rotateRight();
            moveForward();
        }
        else if(isLeftWall() && isFrontWall() && !isRightWall()){
            rotateRight();
            moveForward();
        }
        
        newPosX = currentPosX;
        newPosY = currentPosY;
        updatePosition(oldPosX,oldPosY,newPosX,newPosY);
    }
    
	private void updatePosition(int oldPosX, int oldPosY, int newPosX, int newPosY) {

		// Determine the change in row/column of the robot
		int deltaX = newPosX - oldPosX;
		int deltaY = newPosY - oldPosY;

		// Update the path in the robot map
		RobotMap.PathGrid[][] pathGrids = null;
		if (_robotMap != null)
			pathGrids = _robotMap.getPathGrids();
		if (pathGrids != null) {
			switch (direction) {
			case EAST:
				pathGrids[oldPosX][oldPosY].cE = true;
				pathGrids[newPosX][newPosY].cW = true;
				break;
			case NORTH:
				pathGrids[oldPosX][oldPosY].cN = true;
				pathGrids[newPosX][newPosY].cS = true;
				break;
			case SOUTH:
				pathGrids[oldPosX][oldPosY].cS = true;
				pathGrids[newPosX][newPosY].cN = true;
				break;
			case WEST:
				pathGrids[oldPosX][oldPosY].cW = true;
				pathGrids[newPosX][newPosY].cE = true;
				break;
			}
		}

		// Update the positions of the sensors
//		for (Sensor s : _sensors) {
//			s.updateSensorPos(s.getSensorPosRow() + deltaRow,
//					s.getSensorPosCol() + deltaCol);
//		}
	}
        
//    public boolean Logic(){
//        return false;
//    }
    
    public boolean isLeftWall () {
        switch(direction){
            case NORTH: 
                    return _grids[currentPosX - 1][currentPosY].isObstacle();   
            case EAST: 
                    return _grids[currentPosX][currentPosY + 1].isObstacle();
            case WEST: 
                    return _grids[currentPosX][currentPosY - 1].isObstacle();
            case SOUTH:
                    return _grids[currentPosX + 1][currentPosY].isObstacle();
            default:
                return false;
        }
    }
//        if(_grids[currentPosX - 1][currentPosY].isObstacle())
//            return true;
//        return false;
//    }
    
    public boolean isRightWall () {
        switch(direction){
            case NORTH: 
                    return _grids[currentPosX + 1][currentPosY].isObstacle();   
            case EAST: 
                    return _grids[currentPosX][currentPosY - 1].isObstacle();
            case WEST: 
                    return _grids[currentPosX][currentPosY + 1].isObstacle();
            case SOUTH:
                    return _grids[currentPosX - 1][currentPosY].isObstacle();
            default:
                return false;
        }
    }
    
    
    public boolean isFrontWall () {
        switch(direction){
            case NORTH: 
                    return _grids[currentPosX][currentPosY + 1].isObstacle();   
            case EAST: 
                    return _grids[currentPosX + 1][currentPosY].isObstacle();
            case WEST: 
                    return _grids[currentPosX -1 ][currentPosY].isObstacle();
            case SOUTH:
                    return _grids[currentPosX][currentPosY - 1].isObstacle();
            default:
                return false;
        }
    }
    
//    public boolean isBorder () {
//        if(direction == direction.NORTH && currentPosY + 1 > 19)
//            return true;
//        else if(direction == direction.WEST && currentPosX - 1 < 1)
//        return false;
//    }
    
    public void moveForward () {
        switch(direction){
            case NORTH:
                currentPosY += 1;
                break;
            case SOUTH:
                currentPosY -= 1;
                break;
            case EAST:
                currentPosX += 1;
                break;
            case WEST:
                currentPosX -= 1;
                break;
            default:
                break;
        }
    }
    
    public void rotateLeft () {
        switch(direction){
            case NORTH:
                direction = direction.WEST;
                break;
            case SOUTH:
                direction = direction.EAST;
                break;
            case EAST:
                direction = direction.NORTH;
                break;
            case WEST:
                direction = direction.SOUTH;
                break;
            default:
                break;
        }
    }
    
    public void rotateRight () {
        switch(direction){
            case NORTH:
                direction = direction.EAST;
                break;
            case SOUTH:
                direction = direction.WEST;
                break;
            case EAST:
                direction = direction.SOUTH;
                break;
            case WEST:
                direction = direction.NORTH;
                break;
            default:
                break;
        }        
    }
    
    public void rotate180 () {
        switch(direction){
            case NORTH:
                direction = direction.SOUTH;
                break;
            case SOUTH:
                direction = direction.NORTH;
                break;
            case EAST:
                direction = direction.WEST;
                break;
            case WEST:
                direction = direction.EAST;
                break;
            default:
                break;
        }
    }
    
    /** For getting the robot's X and Y coordinates relative the the map */
    public int getCurrentPosX() {
            return currentPosX;
    }

    
    public int getCurrentPosY() {
            return currentPosY;
    }
    
    /** Returns the current direction that the robot is facing */
    public DIRECTION getDirection() {
            return direction;
    }
}