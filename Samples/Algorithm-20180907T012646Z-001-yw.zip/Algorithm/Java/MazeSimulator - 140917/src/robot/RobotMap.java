/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.BorderFactory;
import javax.swing.border.Border;

import robot.RobotConstant.DIRECTION;
import map.Map;
import map.Constants;
import map.MapUI;

public class RobotMap extends Map {
    // For measuring size of the canvas
    private boolean _bMeasured = false;

    // Size of the map
    private int _mapWidth = 0;
    private int _mapHeight = 0;
    // For rendering the map efficiently
    private MapGrid [][] _mapGrids = null;
    private PathGrid [][] _pathGrids = null;

    // Reference to the robot
    private Robot _robot = null;

    // For rendering the robot
    private int _robotOutlineSize = 0;
    private int _robotSize = 0;
    private int [] _arrowX = null;
    private int [] _arrowY = null;

    // For choice of path to render
    private boolean _bShortestPath = false;

    private boolean _bDisplayTruthValues = true;

    public RobotMap(final MapUI mapUI) {
            super();
    }

    public void paintMap(Graphics g){
        if (!_bMeasured) {
            _mapWidth = this.getWidth();
            _mapHeight = this.getHeight();

            System.out.println("\nRobotMap Graphics g; Map width: " + _mapWidth
                            + ", Map height: " + _mapHeight);

            // Calculate the map & path grids for rendering
            _mapGrids = new MapGrid[Constants.MAP_ROWS][Constants.MAP_COLS];
            _pathGrids = new PathGrid[Constants.MAP_ROWS][Constants.MAP_COLS];
            for (int mapRow = 0; mapRow < Constants.MAP_ROWS; mapRow++) {
                    for (int mapCol = 0; mapCol < Constants.MAP_COLS; mapCol++) {
                            _mapGrids[mapRow][mapCol] = new MapGrid(
                                            mapCol * Constants.GRID_SIZE,
                                            mapRow * Constants.GRID_SIZE,
                                            Constants.GRID_SIZE);

                            _pathGrids[mapRow][mapCol] = new PathGrid(
                                            _mapGrids[mapRow][mapCol]);
                    }
            }		

            _bMeasured = true;
        }
    }
    
    private class MapGrid {
		public int borderX;
		public int borderY;
		public int borderSize;
		
		public int gridX;
		public int gridY;
		public int gridSize;
		
		public MapGrid(int borderX, int borderY, int borderSize) {
			this.borderX = borderX;
			this.borderY = borderY;
			this.borderSize = borderSize;
			
			this.gridX = borderX + Constants.GRID_LINE_WEIGHT;
			this.gridY = borderY + Constants.GRID_LINE_WEIGHT;
			this.gridSize = borderSize - (Constants.GRID_LINE_WEIGHT * 2);
		}
	}
	
	public class PathGrid {
		
		public int nX, nY;
		public int eX, eY;
		public int sX, sY;
		public int wX, wY;
		public int cX, cY;
		
		public boolean cN, cE, cS, cW;
		
		public PathGrid(MapGrid mapGrid) {
			
			int halfGridSize = mapGrid.borderSize / 2;
			
			this.nX = mapGrid.borderX + halfGridSize;
			this.nY = mapGrid.borderY;
			
			this.eX = mapGrid.borderX + mapGrid.borderSize;
			this.eY = mapGrid.borderY + halfGridSize;
			
			this.sX = mapGrid.borderX + halfGridSize;
			this.sY = mapGrid.borderY + mapGrid.borderSize;
			
			this.wX = mapGrid.borderX;
			this.wY = mapGrid.borderY + halfGridSize;
			
			this.cX = mapGrid.borderX + halfGridSize;
			this.cY = mapGrid.borderY + halfGridSize;
			
			cN = cE = cS = cW = false;
		}
	}
}
