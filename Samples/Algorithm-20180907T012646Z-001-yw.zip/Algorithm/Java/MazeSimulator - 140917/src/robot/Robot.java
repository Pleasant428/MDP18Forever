/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Queue;
import java.util.Stack;

import javax.swing.Timer;

import map.Grid;
import map.Constants;
import map.MapUI;
import robot.RobotConstant.DIRECTION;


public class Robot {

    int currentPosX, currentPosY;
    DIRECTION direction = null;
    
    // Robot's robot map
    private transient RobotMap _robotMap = null; // For determining next action
    private transient MapUI _mapUI = null; // For detecting obstacles
    
    public Robot(int currentPosX, int currentPosY, DIRECTION direction){
        this.currentPosX = currentPosX;
        this.currentPosY = currentPosY;
        this.direction = direction;
    }
    
    public boolean isLeftWall () {
        if(_robotMap.getMapGrids[currentPosX - 1][currentPosY].isObstacle())
            return true;
        return false;
    }
    
    public boolean isRightWall () {
        return false;
    }
    
    public boolean isFrontWall () {
        
        return false;
    }
    
    public boolean isBorder () {
        if(direction == direction.NORTH && currentPosY + 1 > 19)
            return true;
        else if(direction == direction.WEST && currentPosX - 1 < 1)
        return false;
    }
    
    public void moveForward () {
        switch(direction){
            case NORTH:
                currentPosY += 1;
                break;
            case SOUTH:
                currentPosY -= 1;
                break;
            case EAST:
                currentPosX += 1;
                break;
            case WEST:
                currentPosX -= 1;
                break;
            default:
                break;
        }
    }
    
    public void rotateLeft () {
        switch(direction){
            case NORTH:
                direction = direction.WEST;
                break;
            case SOUTH:
                direction = direction.EAST;
                break;
            case EAST:
                direction = direction.NORTH;
                break;
            case WEST:
                direction = direction.SOUTH;
                break;
            default:
                break;
        }
    }
    
    public void rotateRight () {
        switch(direction){
            case NORTH:
                direction = direction.EAST;
                break;
            case SOUTH:
                direction = direction.WEST;
                break;
            case EAST:
                direction = direction.SOUTH;
                break;
            case WEST:
                direction = direction.NORTH;
                break;
            default:
                break;
        }        
    }
    
    public void rotate180 () {
        switch(direction){
            case NORTH:
                direction = direction.SOUTH;
                break;
            case SOUTH:
                direction = direction.NORTH;
                break;
            case EAST:
                direction = direction.WEST;
                break;
            case WEST:
                direction = direction.EAST;
                break;
            default:
                break;
        }
    }
    
    
}
