/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Queue;
import java.util.Stack;

import javax.swing.Timer;

import map.Grid;
import map.Constants;
import map.MapUI;
import robot.RobotConstant.DIRECTION;


public class Robot {

    int currentPosX, currentPosY;
    DIRECTION direction = null;
    
    // Robot's robot map
    private transient RobotMap _robotMap = null; // For determining next action
    private transient MapUI _mapUI = null; // For detecting obstacles
    //private Grid[][] _grids = _robotMap.getMapGrids();
    ArrayList<Integer> previousPosX;
    ArrayList<Integer> previousPosY;
    
    
    
    
    public Robot(int currentPosX, int currentPosY, DIRECTION direction){
        this.currentPosX = currentPosX;
        this.currentPosY = currentPosY;
        this.direction = direction;
    }
    
    public void setRobotMap(RobotMap robotMap) {
		_robotMap = robotMap;

		// Pass a reference of the robot to the robot map
		// Just for rendering purposes
		_robotMap.setRobot(this);
	}
    
    public void PossibleMove(){
        int oldPosX, oldPosY, newPosX, newPosY;
        
        oldPosX = currentPosX;
        oldPosY = currentPosY;

            if(!isLeftWall() && !isFrontWall() && !isRightWall()){
                rotateLeft();
                moveForward();
            }
            else if (!isLeftWall() && !isFrontWall() && isRightWall()){
                rotateLeft();
                moveForward();
            }
            else if(isLeftWall() && !isFrontWall() && !isRightWall()){
                moveForward();
            }
            else if(!isLeftWall() && isFrontWall() && !isRightWall()){
                rotateRight();
                moveForward();
            }
            else if(isLeftWall() && isFrontWall() && !isRightWall()){
                rotateRight();
                moveForward();
            }
        
        newPosX = currentPosX;
        newPosY = currentPosY;
        updatePosition(oldPosX,oldPosY,newPosX,newPosY);
    }
    
	private void updatePosition(int oldPosX, int oldPosY, int newPosX, int newPosY) {

		// Determine the change in row/column of the robot
		int deltaX = newPosX - oldPosX;
		int deltaY = newPosY - oldPosY;

		// Update the path in the robot map
		RobotMap.PathGrid[][] pathGrids = null;
		if (_robotMap != null)
			pathGrids = _robotMap.getPathGrids();
		if (pathGrids != null) {
			switch (direction) {
			case EAST:
				pathGrids[oldPosX][oldPosY].cE = true;
				pathGrids[newPosX][newPosY].cW = true;
				break;
			case NORTH:
				pathGrids[oldPosX][oldPosY].cN = true;
				pathGrids[newPosX][newPosY].cS = true;
				break;
			case SOUTH:
				pathGrids[oldPosX][oldPosY].cS = true;
				pathGrids[newPosX][newPosY].cN = true;
				break;
			case WEST:
				pathGrids[oldPosX][oldPosY].cW = true;
				pathGrids[newPosX][newPosY].cE = true;
				break;
			}
		}

		// Update the positions of the sensors
//		for (Sensor s : _sensors) {
//			s.updateSensorPos(s.getSensorPosRow() + deltaRow,
//					s.getSensorPosCol() + deltaCol);
//		}
	}
        
//    public boolean Logic(){
//        return false;
//    }
    public void DepthFirstSearch(){
        ArrayList<Integer> neighbourX;
        ArrayList<Integer> neighbourY;
        
    }

//===============================================================Conversion Of Index =======================================================================
    public int ConvertToIndex(int currentPosX, int currentPosY){
        return currentPosX + (currentPosY * 15) ;
    }
     public int ConvertPosX(int currentIndex){
         return currentIndex % 15;
     }
     public int ConvertPosY(int currentIndex){
         return currentIndex / 15;
     }   

     
//=====================================================================Check Wall============================================================================     
    public boolean isLeftWall () {
        int leftWallX, leftWallY;
        
        Grid[][] _grids = _robotMap.getMapGrids();
        
        switch(direction){
            case NORTH: 
                leftWallX = currentPosX - 1;
                leftWallY = currentPosY;
                
                if(leftWallX < 0)
                    return true;
                else if(leftWallX >= 0){
                    for(int i = leftWallY; i < leftWallY + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[leftWallX][i].isExplored() && _grids[leftWallX][i].isObstacle())  
                            return true;
                    return false;
                }      
            case EAST: 
                
                leftWallX = currentPosX;
                leftWallY = currentPosY + RobotConstant.ROBOT_SIZE;
                   
                if(leftWallY > 19)
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallX; i < leftWallX + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[i][leftWallY].isExplored() && _grids[i][leftWallY].isObstacle())  
                            return true;
                    return false;
                } 
            case WEST: 
                leftWallX = currentPosX;
                leftWallY = currentPosY - 1;
                    
                if(leftWallY < 0)
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallX; i < leftWallX + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[i][leftWallY].isExplored() && _grids[i][leftWallY].isObstacle())  
                            return true;
                    return false;
                } 
            case SOUTH:
                leftWallX = currentPosX + RobotConstant.ROBOT_SIZE;
                leftWallY = currentPosY ;
                    
                if(leftWallX > 14 )
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallY; i < leftWallY + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[leftWallX][i].isExplored() && _grids[leftWallX][i].isObstacle())  
                            return true;
                    return false;
                } 
            default:
                return false;
        }
    }
    
    public boolean isRightWall () {
        int leftWallX, leftWallY;
        
        Grid[][] _grids = _robotMap.getMapGrids();
        
        switch(direction){
            case NORTH: 
                leftWallX = currentPosX + RobotConstant.ROBOT_SIZE;
                leftWallY = currentPosY ;
                    
                if(leftWallX > 14 )
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallY; i < leftWallY + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[leftWallX][i].isExplored() && _grids[leftWallX][i].isObstacle())  
                            return true;
                    return false;
                } 
            case EAST:
                leftWallX = currentPosX;
                leftWallY = currentPosY - 1;
                    
                if(leftWallY < 0 )
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallX; i < leftWallX + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[i][leftWallY].isExplored() && _grids[i][leftWallY].isObstacle())  
                            return true;
                    return false;
                } 
            case WEST:
                leftWallX = currentPosX;
                leftWallY = currentPosY + RobotConstant.ROBOT_SIZE;
                    
                if(leftWallY > 14 )
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallX; i < leftWallX + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[i][leftWallY].isExplored() && _grids[i][leftWallY].isObstacle())  
                            return true;
                    return false;
                } 
            case SOUTH:
                leftWallX = currentPosX - 1;
                leftWallY = currentPosY;
                    
                if(leftWallY < 0 )
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallY; i < leftWallY + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[leftWallX][i].isExplored() && _grids[leftWallX][i].isObstacle())  
                            return true;
                    return false;
                }
            default:
                return false;
        }
    }
    
    
    public boolean isFrontWall () {
        int leftWallX, leftWallY;
        
        Grid[][] _grids = _robotMap.getMapGrids();
        
        switch(direction){
            case NORTH: 
                leftWallX = currentPosX;
                leftWallY = currentPosY + RobotConstant.ROBOT_SIZE;
                    
                if(leftWallY >19 )
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallX; i < leftWallX + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[i][leftWallY].isExplored() && _grids[i][leftWallY].isObstacle())  
                            return true;
                    return false;
                }
                  
            case EAST: 
                leftWallX = currentPosX + RobotConstant.ROBOT_SIZE;
                leftWallY = currentPosY;
                    
                if(leftWallX >14 )
                    return true;
                else if(leftWallX >= 0){
                    for(int i = leftWallY; i < leftWallY + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[leftWallX][i].isExplored() && _grids[leftWallX][i].isObstacle())  
                            return true;
                    return false;
                }
            case WEST:
                leftWallX = currentPosX - 1;
                leftWallY = currentPosY;
                    
                if(leftWallX < 0 )
                    return true;
                else if(leftWallX >= 0){
                    for(int i = leftWallY; i < leftWallY + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[leftWallX][i].isExplored() && _grids[leftWallX][i].isObstacle())  
                            return true;
                    return false;
                }
            case SOUTH:
                leftWallX = currentPosX;
                leftWallY = currentPosY - 1;
                    
                if(leftWallY < 0 )
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallX; i < leftWallX + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[i][leftWallY].isExplored() && _grids[i][leftWallY].isObstacle())  
                            return true;
                    return false;
                }
            default:
                return false;
        }
    }
//=============================================================For Movement===============================================================================
    public void moveForward () {
        switch(direction){
            case NORTH:
                currentPosY += 1;
                markCurrentPosAsVisited();
                break;
            case SOUTH:
                currentPosY -= 1;
               markCurrentPosAsVisited();
                break;
            case EAST:
                currentPosX += 1;
                markCurrentPosAsVisited();
                break;
            case WEST:
                currentPosX -= 1;
                markCurrentPosAsVisited();
                break;
            default:
                break;
        }
    }
    
    public void rotateLeft () {
        switch(direction){
            case NORTH:
                direction = direction.WEST;
                break;
            case SOUTH:
                direction = direction.EAST;
                break;
            case EAST:
                direction = direction.NORTH;
                break;
            case WEST:
                direction = direction.SOUTH;
                break;
            default:
                break;
        }
    }
    
    public void rotateRight () {
        switch(direction){
            case NORTH:
                direction = direction.EAST;
                break;
            case SOUTH:
                direction = direction.WEST;
                break;
            case EAST:
                direction = direction.SOUTH;
                break;
            case WEST:
                direction = direction.NORTH;
                break;
            default:
                break;
        }        
    }
    
    public void rotate180 () {
        switch(direction){
            case NORTH:
                direction = direction.SOUTH;
                break;
            case SOUTH:
                direction = direction.NORTH;
                break;
            case EAST:
                direction = direction.WEST;
                break;
            case WEST:
                direction = direction.EAST;
                break;
            default:
                break;
        }
    }
    
//==========================================================Function for Exploration==========================================================================
    
    /** For getting the robot's X and Y coordinates relative the the map */
    public int getCurrentPosX() {
            return currentPosX;
    }

    
    public int getCurrentPosY() {
            return currentPosY;
    }
    
    /** Returns the current direction that the robot is facing */
    public DIRECTION getDirection() {
            return direction;
    }
    
    public void markStartAsExplored(){
		int robotMapPosX = this.getCurrentPosX();
		int robotMapPosY = this.getCurrentPosY();
                System.out.println();

		Grid[][] robotMapGrids = _robotMap.getMapGrids();
		for (int mapRow = robotMapPosX; mapRow < robotMapPosX
				+ RobotConstant.ROBOT_SIZE; mapRow++) {
			for (int mapCol = robotMapPosY; mapCol < robotMapPosY
					+ RobotConstant.ROBOT_SIZE; mapCol++) {

				robotMapGrids[mapRow][mapCol].setExplored(true);
			}
		}
	}
    private void markCurrentPosAsVisited() {
        Grid[][] robotMapGrids = _robotMap.getMapGrids();
		
		for (int mapRow = currentPosX; mapRow < currentPosX
				+ RobotConstant.ROBOT_SIZE; mapRow++) {
			for (int mapCol = currentPosY; mapCol < currentPosY
					+ RobotConstant.ROBOT_SIZE; mapCol++) {

				robotMapGrids[mapRow][mapCol].markAsVisited();
			}
		}
    }
    
    //==========================================================================For A* Star Search========================================================================
    
    public ArrayList<Integer> AStarSearch(int start, int goal, int[] mapBit){                        //Function of A* search algorithm
        boolean closedSet[] = new boolean[300];                                                             //The set of nodes already evaluated
        ArrayList<Integer> openSet = new ArrayList();                                                       //The set of currently discovered nodes that are not evaluated yet
        int cameFrom[] = new int[300];                                                                      //CameFrom will eventually contain the most efficient previous step
        double gScore[] = new double[300];                                                                  //For each node, the cost of getting from the start node to that node.
        double fScore[] = new double[300];                                                                  //For each node, the total cost of getting from the start node to the goal
        double gScoreTemp;
        ArrayList<Integer> neighbour;
        int currentIndex;
    
        Arrays.fill(closedSet, false);
        Arrays.fill(cameFrom, -1);
        Arrays.fill(gScore, 999);
        Arrays.fill(fScore, 999);
        
        openSet.add(start);
        gScore[start] = 0;
        fScore[start] = HeuristicDist(start, goal);
        
        while (openSet.size()!=0){
           openSet = SortingfScore(fScore, openSet);
           currentIndex = openSet.get(0);
           openSet.remove(0);

           if(currentIndex == goal){
                return ShortestPathResult(cameFrom, currentIndex, start);
           }
           closedSet[currentIndex] = true;
           neighbour = currentNeighbour(currentIndex, mapBit);

           for(int i =0; i<neighbour.size(); i++){
               if(closedSet[neighbour.get(i)]){
                   continue;
               }
               if(CheckNeighbour(neighbour.get(i), openSet) == false){
                   openSet.add(neighbour.get(i));
               }
               
               gScoreTemp = gScore[currentIndex] + 1;
               
               if(gScoreTemp >= gScore[neighbour.get(i)]){
                   continue;
               }
               else{
                   cameFrom[neighbour.get(i)] = currentIndex;
                   gScore[neighbour.get(i)] = gScoreTemp;
                   fScore[neighbour.get(i)] = gScore[neighbour.get(i)] + HeuristicDist(neighbour.get(i), goal);
               }
            }
        }
        return null;        //No Solution
    }
    
    public double HeuristicDist(int start, int end){                                                 //Function for calculation of Heuristic Distance
        int startX = ConvertPosX(start);
        int startY = ConvertPosY(start);
        int endX = ConvertPosX(end);
        int endY = ConvertPosY(end);
        
        return Math.abs(startX-endX) + Math.abs(startY-endY) ;
    }
    
    public ArrayList<Integer> SortingfScore(double[] fScore, ArrayList<Integer> openSet){
        double lowestfScore = 9999;
        int lowestfIndex = -1;
        
        for(int i =0; i<openSet.size(); i++){
            if(fScore[openSet.get(i)] <= lowestfScore){
                lowestfScore = fScore[openSet.get(i)];
                lowestfIndex = i;
            }
        }
        return SwapLowestInfront(openSet, lowestfIndex);
    }
    
    public ArrayList<Integer> SwapLowestInfront(ArrayList<Integer> openSet, int lowestfIndex){
        int temp;
        temp =  openSet.get(lowestfIndex);
        openSet.set(lowestfIndex, openSet.get(0));
        openSet.set(0, temp);
        
        return openSet;
    }
    
    public ArrayList<Integer> ShortestPathResult(int[] cameFrom, int currentIndex, int start){ //Added start
        ArrayList<Integer> path = new ArrayList();
        while(cameFrom[currentIndex] != -1){
            path.add(currentIndex);
            currentIndex = cameFrom[currentIndex];
        }
        path.add(start);
        return path;
    }
    
    public static boolean CheckNeighbour(int neighbour, ArrayList<Integer> openSet){
        for(int i = 0; i<openSet.size(); i++){
            if(openSet.get(i) == neighbour){
                return true;
            }
        }
        return false;
    }
    
    public static ArrayList<Integer> currentNeighbour(int currentIndex, int[] mapBit){
        ArrayList<Integer> cNeighbour = new ArrayList();
        int right = currentIndex + 1;
        int left = currentIndex - 1;
        int top = currentIndex + 15;
        int bottom = currentIndex - 15;
     
       if(right %15 != 14&& mapBit[right] != 1)
           cNeighbour.add(right);
       if(left % 15 != 0 && mapBit[left] != 1)
           cNeighbour.add(left);
       if(top < 300 && mapBit[top] != 1)
           cNeighbour.add(top);
       if(bottom >= 0 && mapBit[bottom] != 1)
           cNeighbour.add(bottom);
       return cNeighbour;
    }
    
//==========================================================================For A* Star Search========================================================================
    
        

//    public boolean isRightWall () {
//        
//        switch(direction){
//            case NORTH: 
//                    return _grids[currentPosX + 2][currentPosY].isObstacle();   
//            case EAST: 
//                    return _grids[currentPosX][currentPosY - 2].isObstacle();
//            case WEST: 
//                    return _grids[currentPosX][currentPosY + 2].isObstacle();
//            case SOUTH:
//                    return _grids[currentPosX - 2][currentPosY].isObstacle();
//            default:
//                return false;
//        }
//    }
//    
//    
//    public boolean isFrontWall () {
//        switch(direction){
//            case NORTH: 
//                    return _grids[currentPosX][currentPosY + 2].isObstacle();   
//            case EAST: 
//                    return _grids[currentPosX + 2][currentPosY].isObstacle();
//            case WEST: 
//                    return _grids[currentPosX - 2][currentPosY].isObstacle();
//            case SOUTH:
//                    return _grids[currentPosX][currentPosY - 2].isObstacle();
//            default:
//                return false;
//        }
//    }    
    
//    public boolean isLeftWall () {
//        switch(direction){
//            case NORTH: 
//                    return _grids[currentPosX - 2][currentPosY].isObstacle();   
//            case EAST: 
//                    return _grids[currentPosX][currentPosY + 2].isObstacle();
//            case WEST: 
//                    return _grids[currentPosX][currentPosY - 2].isObstacle();
//            case SOUTH:
//                    return _grids[currentPosX + 2][currentPosY].isObstacle();
//            default:
//                return false;
//        }
//    }    
    
//    public ArrayList<Integer> StoreNeighbour(int currentPosX, int currentPosY, DIRECTION direction){
//        
//        ArrayList<Integer> storeNeighbour = new ArrayList();
//        
//        switch(direction){
//            case NORTH:
//                //store left neighbour
//                if(!isLeftWall()){
//                    storeNeighbour.add(ConvertToIndex(currentPosX - 1, currentPosY));
//                    
//                }
//                //store front neighbour
//                if(!isFrontWall ()){
//                    storeNeighbour.add(ConvertToIndex(currentPosX, currentPosY + 1));
//                }
//                //store right neighbour
//                if(!isRightWall()){
//                    storeNeighbour.add(ConvertToIndex(currentPosX + 1, currentPosY));
//                }
//                break;
//            case EAST:
//                if(!isLeftWall()){
//                    storeNeighbour.add(ConvertToIndex(currentPosX, currentPosY + 1));
//                }
//                //store front neighbour
//                if(!isFrontWall ()){
//                    storeNeighbour.add(ConvertToIndex(currentPosX + 1, currentPosY + 1));
//                }
//                //store right neighbour
//                if(!isRightWall()){
//                    storeNeighbour.add(ConvertToIndex(currentPosX - 1, currentPosY));
//                }
//                break;
//            case SOUTH:
//                if(!isLeftWall()){
//                    storeNeighbour.add(ConvertToIndex(currentPosX + 1, currentPosY));
//                }
//                //store front neighbour
//                if(!isFrontWall ()){
//                    storeNeighbour.add(ConvertToIndex(currentPosX, currentPosY - 1));
//                }
//                //store right neighbour
//                if(!isRightWall()){
//                    storeNeighbour.add(ConvertToIndex(currentPosX - 1, currentPosY));
//                }
//                break;
//            case WEST:
//                if(!isLeftWall()){
//                    storeNeighbour.add(ConvertToIndex(currentPosX, currentPosY - 1));
//                }
//                //store front neighbour
//                if(!isFrontWall ()){
//                    storeNeighbour.add(ConvertToIndex(currentPosX - 1, currentPosY));
//                }
//                //store right neighbour
//                if(!isRightWall()){
//                    storeNeighbour.add(ConvertToIndex(currentPosX, currentPosY + 1));
//                }
//                break;
//            default:
//                //need to backtrack
//                break;
//        }
//        return storeNeighbour;
//    }
}