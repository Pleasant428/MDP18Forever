/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Queue;
import java.util.Stack;

import javax.swing.Timer;

import map.Grid;
import map.Constants;
import map.MapUI;
import robot.RobotConstant.DIRECTION;


public class Robot {

    int currentCol, currentRow;
    DIRECTION direction = null;
    
    // Robot's robot map
    private transient RobotMap _robotMap = null; // For determining next action
    private transient MapUI _mapUI = null; // For detecting obstacles
    //private Grid[][] _grids = _robotMap.getMapGrids();
    ArrayList<Integer> previousCol;
    ArrayList<Integer> previousRow;
    
    // Robot's settings for exploration
    private int _stepsPerSecond = RobotConstant.DEFAULT_STEPS_PER_SECOND;
    private int _coverageLimit = RobotConstant.DEFAULT_COVERAGE_LIMIT;
    private int _timeLimit = RobotConstant.DEFAULT_TIME_LIMIT;
//    private boolean _bCoverageLimited = false;
//    private boolean _bTimeLimited = false;
    
    // Some memory for the robot here
    private transient boolean _bPreviousLeftWall = false;
    private transient boolean _bReachedGoal = false;
    private transient boolean _bExplorationComplete = false;
    
    // Timer for controlling robot movement
    private transient Timer _exploreTimer = null;
    private transient int _timerIntervals = 0;

    // Number of explored grids required to reach coverage limit
    private transient int _explorationTarget = 0;

    // Elapsed time for the exploration phase (in milliseconds)
    private transient int _elapsedExplorationTime = 0;
    
    int G = 0;
    
    
    
    
    public Robot(int currentRow, int currentCol, DIRECTION direction){
        this.currentRow = currentRow;
        this.currentCol = currentCol;
        this.direction = direction;
    }
    
    public void setRobotMap(RobotMap robotMap) {
		_robotMap = robotMap;

		// Pass a reference of the robot to the robot map
		// Just for rendering purposes
		_robotMap.setRobot(this);
	}
    
    public void setMapUI(final MapUI mapUI) {
            _mapUI = mapUI;
    }
    
    public void startExplore(){
        // Calculate timer intervals based on the user selected steps per second
        _timerIntervals = ((1000 * 1000 / _stepsPerSecond) / 1000);
        System.out.println("Steps Per Second: " + _stepsPerSecond
                + ", Timer Interval: " + _timerIntervals);

        // Calculate number of explored grids required
        _explorationTarget = (int) ((_coverageLimit / 100.0) * ((Constants.MAP_ROWS) * (Constants.MAP_COLS)));
        System.out.println("Exploration target (In grids): "
                + _explorationTarget);

        // Reset the elapsed exploration time (in milliseconds)
        _elapsedExplorationTime = 0;

        _exploreTimer = new Timer(_timerIntervals, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                if (_exploreTimer != null && _bExplorationComplete) {
                    _exploreTimer.stop();
                    _exploreTimer = null;
                } else {
                    // Make the next move
                    makeNextMove();

                    // Update elapsed time
                    _elapsedExplorationTime += _timerIntervals;
                }
            }
        });
        _exploreTimer.setRepeats(true);
        _exploreTimer.setInitialDelay(1000);
        _exploreTimer.start();
    }
    
    public void makeNextMove(){
        // Sense its surroundings
        //this.sense();
        

        _robotMap.revalidate();
        _robotMap.repaint();

        // Logic to make the next move
        //this.logic();
        this.PossibleMove();
    }
    
    public void PossibleMove(){
        int oldCol, oldRow, newCol, newRow;
        
        oldCol = currentCol;
        oldRow = currentRow;

            if(!isLeftWall() && !isFrontWall() && !isRightWall()){
                System.out.println("A: " + G);
                rotateLeft();
                moveForward();
                G++;
            }
            else if (!isLeftWall() && !isFrontWall() && isRightWall()){
                System.out.println("B: " + G);
                rotateLeft();
                moveForward();
                G++;
            }
            else if(isLeftWall() && !isFrontWall() && !isRightWall()){
                System.out.println("C: " + G);
                moveForward();G++;
            }
            else if(!isLeftWall() && isFrontWall() && !isRightWall()){
                System.out.println("D: " + G);
                rotateRight();
                moveForward();G++;
            }
            else if(isLeftWall() && isFrontWall() && !isRightWall()){
                System.out.println("E: " + G);
                rotateRight();
                moveForward();G++;
            }
        
        newCol = currentCol;
        newRow = currentRow;
        updatePosition(oldRow,oldCol,newRow,newCol);
    }
    
	private void updatePosition(int oldRow, int oldCol, int newRow, int newCol) {

		// Determine the change in row/column of the robot
                int deltaRow = newRow - oldRow;
		int deltaCol = newCol - oldCol;

		// Update the path in the robot map
		RobotMap.PathGrid[][] pathGrids = null;
		if (_robotMap != null)
			pathGrids = _robotMap.getPathGrids();
		if (pathGrids != null) {
			switch (direction) {
			case EAST:
				pathGrids[oldRow][oldCol].cE = true;
				pathGrids[newRow][newCol].cW = true;
				break;
			case NORTH:
				pathGrids[oldRow][oldCol].cN = true;
				pathGrids[newRow][newCol].cS = true;
				break;
			case SOUTH:
				pathGrids[oldRow][oldCol].cS = true;
				pathGrids[newRow][newCol].cN = true;
				break;
			case WEST:
				pathGrids[oldRow][oldCol].cW = true;
				pathGrids[newRow][newCol].cE = true;
				break;
			}
		}

		// Update the positions of the sensors
//		for (Sensor s : _sensors) {
//			s.updateSensorPos(s.getSensorPosRow() + deltaRow,
//					s.getSensorPosCol() + deltaCol);
//		}
	}
        
//    public boolean Logic(){
//        return false;
//    }
//    public void DepthFirstSearch(){
//        ArrayList<Integer> neighbourX;
//        ArrayList<Integer> neighbourY;
//        
//    }

//===============================================================Conversion Of Index =======================================================================
    public int ConvertToIndex(int currentRow, int currentCol){
        return currentCol + (currentRow * 15) ;
    }
     public int ConvertCol(int currentIndex){
         return currentIndex % 15;
     }
     public int ConvertRow(int currentIndex){
         return currentIndex / 15;
     }   

     
//=====================================================================Check Wall============================================================================     
    public boolean isLeftWall () {
        int leftWallX, leftWallY;
        
        Grid[][] _grids = _robotMap.getMapGrids();
        
        switch(direction){
            case NORTH: 
                leftWallX = currentCol - 1;
                leftWallY = currentRow;
                
                if(leftWallX < 0)
                    return true;
                else if(leftWallX >= 0){
                    for(int i = leftWallY; i < leftWallY + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[i][leftWallX].isExplored() && _grids[i][leftWallX].isObstacle())  
                            return true;
                    return false;
                }      
            case EAST: 
                
                leftWallX = currentCol;
                leftWallY = currentRow - 1;
                   
                if(leftWallY < 0)
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallX; i < leftWallX + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[leftWallY][i].isExplored() && _grids[leftWallY][i].isObstacle())  
                            return true;
                    return false;
                } 
            case WEST: 
                leftWallX = currentCol;
                leftWallY = currentRow + RobotConstant.ROBOT_SIZE;
                    
                if(leftWallY >19)
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallX; i < leftWallX + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[leftWallY][i].isExplored() && _grids[leftWallY][i].isObstacle())  
                            return true;
                    return false;
                } 
            case SOUTH:
                leftWallX = currentCol + RobotConstant.ROBOT_SIZE;
                leftWallY = currentRow ;
                    
                if(leftWallX > 14 )
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallY; i < leftWallY + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[i][leftWallX].isExplored() && _grids[i][leftWallX].isObstacle())  
                            return true;
                    return false;
                } 
            default:
                return false;
        }
    }
    
    public boolean isRightWall () {
        int leftWallX, leftWallY;
        
        Grid[][] _grids = _robotMap.getMapGrids();
        
        switch(direction){
            case NORTH: 
                leftWallX = currentCol + RobotConstant.ROBOT_SIZE;
                leftWallY = currentRow ;
                    
                if(leftWallX > 14 )
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallY; i < leftWallY + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[i][leftWallX].isExplored() && _grids[i][leftWallX].isObstacle())  
                            return true;
                    return false;
                } 
            case EAST:
                leftWallX = currentCol;
                leftWallY = currentRow + RobotConstant.ROBOT_SIZE;
                    
                if(leftWallY >19 )
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallX; i < leftWallX + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[leftWallY][i].isExplored() && _grids[leftWallY][i].isObstacle())  
                            return true;
                    return false;
                } 
            case WEST:
                leftWallX = currentCol;
                leftWallY = currentRow - 1;
                    
                if(leftWallY < 0 )
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallX; i < leftWallX + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[leftWallY][i].isExplored() && _grids[leftWallY][i].isObstacle())  
                            return true;
                    return false;
                } 
            case SOUTH:
                leftWallX = currentCol - 1;
                leftWallY = currentRow;
                    
                if(leftWallY < 0 )
                    return true;
                else if(leftWallY >= 0){
                    for(int i = leftWallY; i < leftWallY + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[i][leftWallX].isExplored() && _grids[i][leftWallX].isObstacle())  
                            return true;
                    return false;
                }
            default:
                return false;
        }
    }
    
    
    public boolean isFrontWall () {
        int frontWallX, frontWallY;
        
        Grid[][] _grids = _robotMap.getMapGrids();
        
        switch(direction){
            case NORTH: 
                frontWallX = currentCol;
                frontWallY = currentRow - 1;
                    
                if(frontWallY < 0 )
                    return true;
                else if(frontWallY >= 0){
                    for(int i = frontWallX; i < frontWallX + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[frontWallY][i].isExplored() && _grids[frontWallY][i].isObstacle())  
                            return true;
                    return false;
                }
                  
            case EAST: 
                frontWallX = currentCol + RobotConstant.ROBOT_SIZE;
                frontWallY = currentRow;
                    
                if(frontWallX >14 )
                    return true;
                else if(frontWallX >= 0){
                    for(int i = frontWallY; i < frontWallY + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[i][frontWallX].isExplored() && _grids[i][frontWallX].isObstacle())  
                            return true;
                    return false;
                }
            case WEST:
                frontWallX = currentCol - 1;
                frontWallY = currentRow;
                    
                if(frontWallX < 0 )
                    return true;
                else if(frontWallX >= 0){
                    for(int i = frontWallY; i < frontWallY + RobotConstant.ROBOT_SIZE; i++)
                        if(_grids[i][frontWallX].isExplored() && _grids[i][frontWallX].isObstacle())  
                            return true;
                    return false;
                }
            case SOUTH:
                frontWallX = currentCol;
                frontWallY = currentRow + RobotConstant.ROBOT_SIZE;
                    
                if(frontWallY >19 )
                    return true;
                else if(frontWallY >= 0){
                    System.out.println("Value: " + (frontWallY + RobotConstant.ROBOT_SIZE));
                    for(int i = frontWallX; i < frontWallX + RobotConstant.ROBOT_SIZE; i++)
                        
                        if(_grids[frontWallY][i].isExplored() && _grids[frontWallY][i].isObstacle())  
                            return true;
                    return false;
                }
            default:
                return false;
        }
    }
//=============================================================For Movement===============================================================================
    public void moveForward () {
        switch(direction){
            case NORTH:
                currentRow -= 1;
                markCurrentPosAsVisited();
                break;
            case SOUTH:
                currentRow += 1;
               markCurrentPosAsVisited();
                break;
            case EAST:
                currentCol += 1;
                markCurrentPosAsVisited();
                break;
            case WEST:
                currentCol -= 1;
                markCurrentPosAsVisited();
                break;
            default:
                break;
        }
    }
    
    public void rotateLeft () {
        switch(direction){
            case NORTH:
                direction = direction.WEST;
                break;
            case SOUTH:
                direction = direction.EAST;
                break;
            case EAST:
                direction = direction.NORTH;
                break;
            case WEST:
                direction = direction.SOUTH;
                break;
            default:
                break;
        }
    }
    
    public void rotateRight () {
        switch(direction){
            case NORTH:
                direction = direction.EAST;
                break;
            case SOUTH:
                direction = direction.WEST;
                break;
            case EAST:
                direction = direction.SOUTH;
                break;
            case WEST:
                direction = direction.NORTH;
                break;
            default:
                break;
        }        
    }
    
    public void rotate180 () {
        switch(direction){
            case NORTH:
                direction = direction.SOUTH;
                break;
            case SOUTH:
                direction = direction.NORTH;
                break;
            case EAST:
                direction = direction.WEST;
                break;
            case WEST:
                direction = direction.EAST;
                break;
            default:
                break;
        }
    }
    
//==========================================================Function for Exploration==========================================================================
    
    /** For getting the robot's X and Y coordinates relative the the map */
    public int getCurrentCol() {
            return currentCol;
    }

    
    public int getCurrentRow() {
            return currentRow;
    }
    
    /** Returns the current direction that the robot is facing */
    public DIRECTION getDirection() {
            return direction;
    }
    
    public void markStartAsExplored(){
		int robotMapCol = this.getCurrentCol();
		int robotMapRow = this.getCurrentRow();
                System.out.println();

		Grid[][] robotMapGrids = _robotMap.getMapGrids();
		for (int mapRow = robotMapRow; mapRow < robotMapRow
				+ RobotConstant.ROBOT_SIZE; mapRow++) {
			for (int mapCol = robotMapCol; mapCol < robotMapCol
					+ RobotConstant.ROBOT_SIZE; mapCol++) {

				robotMapGrids[mapRow][mapCol].setExplored(true);
			}
		}
	}
    private void markCurrentPosAsVisited() {
        Grid[][] robotMapGrids = _robotMap.getMapGrids();
//        System.out.println("FIRST   ROW: " + mapRow + " COL: " + mapCol);
		
		for (int mapRow = currentRow; mapRow < currentRow
				+ RobotConstant.ROBOT_SIZE; mapRow++) {
			for (int mapCol = currentCol; mapCol < currentCol
					+ RobotConstant.ROBOT_SIZE; mapCol++) {
                         System.out.println("ROW: " + mapRow + " COL: " + mapCol + " DIRECTION : " + direction);
				robotMapGrids[mapRow][mapCol].markAsVisited();
			}
		}
    }
    
    //==========================================================================For A* Star Search========================================================================
    
    public ArrayList<Integer> AStarSearch(int start, int goal, int[] mapBit){                        //Function of A* search algorithm
        boolean closedSet[] = new boolean[300];                                                             //The set of nodes already evaluated
        ArrayList<Integer> openSet = new ArrayList();                                                       //The set of currently discovered nodes that are not evaluated yet
        int cameFrom[] = new int[300];                                                                      //CameFrom will eventually contain the most efficient previous step
        double gScore[] = new double[300];                                                                  //For each node, the cost of getting from the start node to that node.
        double fScore[] = new double[300];                                                                  //For each node, the total cost of getting from the start node to the goal
        double gScoreTemp;
        ArrayList<Integer> neighbour;
        int currentIndex;
    
        Arrays.fill(closedSet, false);
        Arrays.fill(cameFrom, -1);
        Arrays.fill(gScore, 999);
        Arrays.fill(fScore, 999);
        
        openSet.add(start);
        gScore[start] = 0;
        fScore[start] = HeuristicDist(start, goal);
        
        while (openSet.size()!=0){
           openSet = SortingfScore(fScore, openSet);
           currentIndex = openSet.get(0);
           openSet.remove(0);

           if(currentIndex == goal){
                return ShortestPathResult(cameFrom, currentIndex, start);
           }
           closedSet[currentIndex] = true;
           neighbour = currentNeighbour(currentIndex, mapBit);

           for(int i =0; i<neighbour.size(); i++){
               if(closedSet[neighbour.get(i)]){
                   continue;
               }
               if(CheckNeighbour(neighbour.get(i), openSet) == false){
                   openSet.add(neighbour.get(i));
               }
               
               gScoreTemp = gScore[currentIndex] + 1;
               
               if(gScoreTemp >= gScore[neighbour.get(i)]){
                   continue;
               }
               else{
                   cameFrom[neighbour.get(i)] = currentIndex;
                   gScore[neighbour.get(i)] = gScoreTemp;
                   fScore[neighbour.get(i)] = gScore[neighbour.get(i)] + HeuristicDist(neighbour.get(i), goal);
               }
            }
        }
        return null;        //No Solution
    }
    
    public double HeuristicDist(int start, int end){                                                 //Function for calculation of Heuristic Distance
        int startX = ConvertCol(start);
        int startY = ConvertRow(start);
        int endX = ConvertCol(end);
        int endY = ConvertRow(end);
        
        return Math.abs(startX-endX) + Math.abs(startY-endY) ;
    }
    
    public ArrayList<Integer> SortingfScore(double[] fScore, ArrayList<Integer> openSet){
        double lowestfScore = 9999;
        int lowestfIndex = -1;
        
        for(int i =0; i<openSet.size(); i++){
            if(fScore[openSet.get(i)] <= lowestfScore){
                lowestfScore = fScore[openSet.get(i)];
                lowestfIndex = i;
            }
        }
        return SwapLowestInfront(openSet, lowestfIndex);
    }
    
    public ArrayList<Integer> SwapLowestInfront(ArrayList<Integer> openSet, int lowestfIndex){
        int temp;
        temp =  openSet.get(lowestfIndex);
        openSet.set(lowestfIndex, openSet.get(0));
        openSet.set(0, temp);
        
        return openSet;
    }
    
    public ArrayList<Integer> ShortestPathResult(int[] cameFrom, int currentIndex, int start){ //Added start
        ArrayList<Integer> path = new ArrayList();
        while(cameFrom[currentIndex] != -1){
            path.add(currentIndex);
            currentIndex = cameFrom[currentIndex];
        }
        path.add(start);
        return path;
    }
    
    public static boolean CheckNeighbour(int neighbour, ArrayList<Integer> openSet){
        for(int i = 0; i<openSet.size(); i++){
            if(openSet.get(i) == neighbour){
                return true;
            }
        }
        return false;
    }
    
    public static ArrayList<Integer> currentNeighbour(int currentIndex, int[] mapBit){
        ArrayList<Integer> cNeighbour = new ArrayList();
        int right = currentIndex + 1;
        int left = currentIndex - 1;
        int top = currentIndex + 15;
        int bottom = currentIndex - 15;
     
       if(right %15 != 14&& mapBit[right] != 1)
           cNeighbour.add(right);
       if(left % 15 != 0 && mapBit[left] != 1)
           cNeighbour.add(left);
       if(top < 300 && mapBit[top] != 1)
           cNeighbour.add(top);
       if(bottom >= 0 && mapBit[bottom] != 1)
           cNeighbour.add(bottom);
       return cNeighbour;
    }
    
//==========================================================================For A* Star Search========================================================================
    
        

//    public boolean isRightWall () {
//        
//        switch(direction){
//            case NORTH: 
//                    return _grids[currentCol + 2][currentRow].isObstacle();   
//            case EAST: 
//                    return _grids[currentCol][currentRow - 2].isObstacle();
//            case WEST: 
//                    return _grids[currentCol][currentRow + 2].isObstacle();
//            case SOUTH:
//                    return _grids[currentCol - 2][currentRow].isObstacle();
//            default:
//                return false;
//        }
//    }
//    
//    
//    public boolean isFrontWall () {
//        switch(direction){
//            case NORTH: 
//                    return _grids[currentCol][currentRow + 2].isObstacle();   
//            case EAST: 
//                    return _grids[currentCol + 2][currentRow].isObstacle();
//            case WEST: 
//                    return _grids[currentCol - 2][currentRow].isObstacle();
//            case SOUTH:
//                    return _grids[currentCol][currentRow - 2].isObstacle();
//            default:
//                return false;
//        }
//    }    
    
//    public boolean isLeftWall () {
//        switch(direction){
//            case NORTH: 
//                    return _grids[currentCol - 2][currentRow].isObstacle();   
//            case EAST: 
//                    return _grids[currentCol][currentRow + 2].isObstacle();
//            case WEST: 
//                    return _grids[currentCol][currentRow - 2].isObstacle();
//            case SOUTH:
//                    return _grids[currentCol + 2][currentRow].isObstacle();
//            default:
//                return false;
//        }
//    }    
    
//    public ArrayList<Integer> StoreNeighbour(int currentCol, int currentRow, DIRECTION direction){
//        
//        ArrayList<Integer> storeNeighbour = new ArrayList();
//        
//        switch(direction){
//            case NORTH:
//                //store left neighbour
//                if(!isLeftWall()){
//                    storeNeighbour.add(ConvertToIndex(currentCol - 1, currentRow));
//                    
//                }
//                //store front neighbour
//                if(!isFrontWall ()){
//                    storeNeighbour.add(ConvertToIndex(currentCol, currentRow + 1));
//                }
//                //store right neighbour
//                if(!isRightWall()){
//                    storeNeighbour.add(ConvertToIndex(currentCol + 1, currentRow));
//                }
//                break;
//            case EAST:
//                if(!isLeftWall()){
//                    storeNeighbour.add(ConvertToIndex(currentCol, currentRow + 1));
//                }
//                //store front neighbour
//                if(!isFrontWall ()){
//                    storeNeighbour.add(ConvertToIndex(currentCol + 1, currentRow + 1));
//                }
//                //store right neighbour
//                if(!isRightWall()){
//                    storeNeighbour.add(ConvertToIndex(currentCol - 1, currentRow));
//                }
//                break;
//            case SOUTH:
//                if(!isLeftWall()){
//                    storeNeighbour.add(ConvertToIndex(currentCol + 1, currentRow));
//                }
//                //store front neighbour
//                if(!isFrontWall ()){
//                    storeNeighbour.add(ConvertToIndex(currentCol, currentRow - 1));
//                }
//                //store right neighbour
//                if(!isRightWall()){
//                    storeNeighbour.add(ConvertToIndex(currentCol - 1, currentRow));
//                }
//                break;
//            case WEST:
//                if(!isLeftWall()){
//                    storeNeighbour.add(ConvertToIndex(currentCol, currentRow - 1));
//                }
//                //store front neighbour
//                if(!isFrontWall ()){
//                    storeNeighbour.add(ConvertToIndex(currentCol - 1, currentRow));
//                }
//                //store right neighbour
//                if(!isRightWall()){
//                    storeNeighbour.add(ConvertToIndex(currentCol, currentRow + 1));
//                }
//                break;
//            default:
//                //need to backtrack
//                break;
//        }
//        return storeNeighbour;
//    }
}