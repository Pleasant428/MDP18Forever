/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mdp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

//public String hexToBin(String s);

/**
 *
 * @author Eugene Tan
 */
public class MDP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         
        // TODO code application logic here\
        String map = "C02080000000000000000000001FF1C000000000010FFC000000000000000000000000010103";        //Hardcoded Map in Hexadecimal
        int mapBit[] = new int[300];                                                                        //Map in Binary     
        int mapBit3x3[] = new int[300];
        int start = 16;                                                                                     //Start Point
        int end = 283;                                                                                      //Goal Point
        int mid = 230;                                                                                      //Mid Point
        String temp;                                                                                        //Temporary storage for 1 Hex to 4 Bit conversion                                                                                    
        String bitString = "";                                                                              //Initialization of map in binary
        ArrayList<Integer> shortestPath = new ArrayList<Integer>();
        ArrayList<Integer> shortestPath1;                                                                   //Shortest Path Result
        ArrayList<Integer> shortestPath2;                                                                   //Shortest Path from mid to goal point
        int k = 299;    
        
        for(int i = 0; i <76; i++){
            temp = String.format("%04d", Integer.parseInt(hexToBin(map.substring(i, i+1))));                //Hexadecimal to Binary conversion
            bitString += temp;
        }
        
        bitString = bitString.substring(2, bitString.length()-2);                                           //Remove first 2 bit and last 2 bit of the String  
        
        for(int h = 0; h<300 ; h++){
            mapBit[h] = Integer.parseInt(bitString.substring(h, h+1));                                      //String to Int Conversion
        }
        for(int h = 0; h<300 ; h++){
            mapBit3x3[h] = Integer.parseInt(ExpendedObs(mapBit).substring(h, h+1));                                 //String to Int Conversion
        }       
        //print bitstring as 2D bitmap
        shortestPath1 = AStarSearch(start, mid, mapBit3x3);
        shortestPath2 = AStarSearch(mid, end, mapBit3x3);
        
        shortestPath.addAll(shortestPath2);                                                                 //concatenate of 2 Arraylist
        shortestPath.addAll(shortestPath1);
        
        Collections.reverse(shortestPath);                                                                  //Reverse element position in Arraylist
        
        for(int i = k - 14; i>=0 ;i++){
            //System.out.print(k);
            if(ExpendedObs(mapBit).charAt(i) == '1')
                System.out.print(" . ");
            else if(ExpendedObs(mapBit).charAt(i) == '0')
                System.out.print(" * ");
            if(i%15 == 14)
                System.out.println("");
            if(i == k){
                i = k - 30;
                k -= 15;
            }            
        }
        System.out.println("");
        k = 299;
        
        
        for(int i = k - 14; i>=0 ;i++){  
            if(i == start)
                System.out.print(" S ");
            else if(i == mid)
                System.out.print(" W ");
            else if(i == end)
                System.out.print(" E ");
            else if(PrintShortestPath(i, shortestPath))
                System.out.print(" @ ");
            else if(bitString.charAt(i) == '1')
                System.out.print(" . ");
            else if(bitString.charAt(i) == '0')
                System.out.print(" * ");
            if(i%15 == 14)
                System.out.println("");
            
            if(i == k){
                i = k - 30;
                k -= 15;
            }            
        }
        
        for(int i = 0; i< shortestPath.size(); i++)                                                        //Printing of shortest path result
        System.out.print(shortestPath.get(i) + " -> ");//@@@@@@@@@@@@@@@@@@@@@@@@     
  }
    
    public static boolean PrintShortestPath(int index, ArrayList<Integer> shortestPath){
        for(int i = 0; i<shortestPath.size(); i++){
            if(index == shortestPath.get(i))
                return true;
        }
        return false;
    }
    
    public static String hexToBin(String hex){                                                              //Function for Hexadecimal to Binary conversion
        int i = Integer.parseInt(hex, 16);
        String bin = Integer.toBinaryString(i);
        return bin;
    }
    
    public static double getXcoor(int gridIndex){
        return gridIndex % 15;
    }
    
    public static double getYcoor(int gridIndex){
        return gridIndex / 15;
    }
    
    public static double HeuristicDist(int start, int end){                                                 //Function for calculation of Heuristic Distance
        double startX = getXcoor(start);
        double startY = getYcoor(start);
        double endX = getXcoor(end);
        double endY = getYcoor(end);
        
        return Math.sqrt( Math.pow(startX - endX, 2) + Math.pow(startY - endY, 2) ) ;
    }
    
    public static ArrayList<Integer> AStarSearch(int start, int goal, int[] mapBit){                        //Function of A* search algorithm
        boolean closedSet[] = new boolean[300];                                                             //The set of nodes already evaluated
        ArrayList<Integer> openSet = new ArrayList();                                                       //The set of currently discovered nodes that are not evaluated yet
        int cameFrom[] = new int[300];                                                                      //CameFrom will eventually contain the most efficient previous step
        double gScore[] = new double[300];                                                                  //For each node, the cost of getting from the start node to that node.
        double fScore[] = new double[300];                                                                  //For each node, the total cost of getting from the start node to the goal
        double gScoreTemp;
        ArrayList<Integer> neighbour;
        int currentIndex;
    
//        for(int i = 0; i < 300; i++){
//            closedSet[i] =def false;
//            cameFrom[i] = -1;
//            gScore[i] = 999;   
//            fScore[i] = 999;
//        }
        Arrays.fill(closedSet, false);
        Arrays.fill(cameFrom, -1);
        Arrays.fill(gScore, 999);
        Arrays.fill(fScore, 999);
        
        openSet.add(start);
        gScore[start] = 0;
        fScore[start] = HeuristicDist(start, goal);
        
        while (openSet.size()!=0){
           openSet = SortingfScore(fScore, openSet);
           currentIndex = openSet.get(0);
           openSet.remove(0);

           if(currentIndex == goal){
                return ShortestPathResult(cameFrom, currentIndex, start);
           }
           closedSet[currentIndex] = true;
           neighbour = currentNeighbour(currentIndex, mapBit);

           for(int i =0; i<neighbour.size(); i++){
               if(closedSet[neighbour.get(i)]){
                   continue;
               }
               if(CheckNeighbour(neighbour.get(i), openSet) == false){
                   openSet.add(neighbour.get(i));
               }
               
               gScoreTemp = gScore[currentIndex] + 1;
               
               if(gScoreTemp >= gScore[neighbour.get(i)]){
                   continue;
               }
               else{
                   cameFrom[neighbour.get(i)] = currentIndex;
                   gScore[neighbour.get(i)] = gScoreTemp;
                   fScore[neighbour.get(i)] = gScore[neighbour.get(i)] + HeuristicDist(neighbour.get(i), goal);
               }
            }
        }
        return null;        //No Solution
    }
    
    public static ArrayList<Integer> SortingfScore(double[] fScore, ArrayList<Integer> openSet){
        double lowestfScore = 9999;
        int lowestfIndex = -1;
        
        for(int i =0; i<openSet.size(); i++){
            if(fScore[openSet.get(i)] <= lowestfScore){
                lowestfScore = fScore[openSet.get(i)];
                lowestfIndex = i;
            }
        }
        return SwapLowestInfront(openSet, lowestfIndex);
    }
    
    public static ArrayList<Integer> SwapLowestInfront(ArrayList<Integer> openSet, int lowestfIndex){
        int temp;
        temp =  openSet.get(lowestfIndex);
        openSet.set(lowestfIndex, openSet.get(0));
        openSet.set(0, temp);
        
        return openSet;
    }
    
    public static ArrayList<Integer> ShortestPathResult(int[] cameFrom, int currentIndex, int start){ //Added start
        ArrayList<Integer> path = new ArrayList();
        while(cameFrom[currentIndex] != -1){
            path.add(currentIndex);
            currentIndex = cameFrom[currentIndex];
        }
        path.add(start);
        return path;
    }
    
    public static ArrayList<Integer> currentNeighbour(int currentIndex, int[] mapBit){
        ArrayList<Integer> cNeighbour = new ArrayList();
        int right = currentIndex + 1;
        int left = currentIndex - 1;
        int top = currentIndex + 15;
        int bottom = currentIndex - 15;
     
       if(right %15 != 14&& mapBit[right] != 1)
           cNeighbour.add(right);
       if(left % 15 != 0 && mapBit[left] != 1)
           cNeighbour.add(left);
       if(top < 300 && mapBit[top] != 1)
           cNeighbour.add(top);
       if(bottom >= 0 && mapBit[bottom] != 1)
           cNeighbour.add(bottom);
       return cNeighbour;
    }
    
    public static boolean CheckNeighbour(int neighbour, ArrayList<Integer> openSet){
        for(int i = 0; i<openSet.size(); i++){
            if(openSet.get(i) == neighbour){
                return true;
            }
        }
        return false;
    }
    
    public static String ExpendedObs (int[] mapBit){
        int mMapBit[] = new int[300];
        StringBuilder builder = new StringBuilder();
        Arrays.fill(mMapBit, 0);
        
        for(int i = 0; i<300; i++){     
            if(i%15 ==0 || i%15 == 14|| i >= 285 || (i >=0 && i < 15))
                mMapBit[i] = 1;
            if(mapBit[i] == 1 && i%15 == 14 && i-15 >=0 && i+15 <300){                                           //right
                mMapBit[i] = 1;
                mMapBit[i-1] = 1;
                mMapBit[i+15] = 1;
                mMapBit[i-15] = 1;
                mMapBit[(i+14)] = 1;
                mMapBit[(i-16)] = 1;
            }
            else if(mapBit[i] == 1 && i%15 == 0 && i-15 >=0 && i+15 <300){                                      //left@@@
                mMapBit[i] = 1;
                mMapBit[i+1] = 1;
                mMapBit[i+15] = 1;
                mMapBit[i-15] = 1;
                mMapBit[(i+16)] = 1;
                mMapBit[(i-14)] = 1;
            }
            else if(mapBit[i] == 1 && i+15 >300 && i-15 >=0 && i%15 < 14 && i%15 > 0){                                       //top
                mMapBit[i] = 1;
                mMapBit[i+1] = 1;
                mMapBit[i-1] = 1;
                mMapBit[i-15] = 1;
                mMapBit[(i-16)] = 1;
                mMapBit[(i-14)] = 1;
            }
            else if(mapBit[i] == 1 && i-15 < 0 && i+15 <300 && i%15 < 14 && i%15 > 0){                                        //bottom
                mMapBit[i] = 1;
                mMapBit[i+1] = 1;
                mMapBit[i-1] = 1;
                mMapBit[i+15] = 1;
                mMapBit[(i+16)] = 1;
                mMapBit[(i+14)] = 1;
            }
            else if(mapBit[i] == 1 && i%15 == 0 && i+15 >299){                                                      //corner top left
                mMapBit[i] = 1;
                mMapBit[i+1] = 1;
                mMapBit[i-14] = 1;
                mMapBit[i-15] = 1;
            }
            else if(mapBit[i] == 1 && i%15 == 14 && i+15 >299){                                                     //corner top right
                mMapBit[i] = 1;
                mMapBit[i-1] = 1;
                mMapBit[i-15] = 1;
                mMapBit[i-16] = 1;
            }
            else if(mapBit[i] == 1 && i%15 == 0 && i-15 < 0){                                                       //corner bottom left
                mMapBit[i] = 1;
                mMapBit[i+1] = 1;
                mMapBit[i+15] = 1;
                mMapBit[i+16] = 1;
            }
            else if(mapBit[i] == 1 && i%15 == 14 && i-15 < 0){                                                      //corner bottom right@@@
                mMapBit[i] = 1;
                mMapBit[i-1] = 1;
                mMapBit[i+14] = 1;
                mMapBit[i+15] = 1;
            }
            else if(mapBit[i] == 1){                                       
                mMapBit[i] = 1;
                mMapBit[i+1] = 1;
                mMapBit[i-1] = 1;
                mMapBit[i+15] = 1;
                mMapBit[i-15] = 1;
                mMapBit[(i+16)] = 1;
                mMapBit[(i-16)] = 1;
                mMapBit[(i+14)] = 1;
                mMapBit[(i-14)] = 1;
            }
            
        }
            for (int i : mMapBit) {
                builder.append(i);
            }    
            
        return builder.toString();
    }
    
}
